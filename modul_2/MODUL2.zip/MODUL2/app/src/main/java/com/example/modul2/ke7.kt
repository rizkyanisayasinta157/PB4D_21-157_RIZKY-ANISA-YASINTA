package com.example.modul2

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class ke7 : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_ke7)
        supportActionBar?.hide()
    }
}